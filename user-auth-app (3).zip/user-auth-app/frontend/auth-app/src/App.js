import React from 'react';
import { Route } from "react-router";
import { BrowserRouter as Router,Switch } from "react-router-dom";
// import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// import Login from './Login';
// import SignUp from './SignUp';
import Login from './Login';
import SignUp from './SignUp';

const App = () => {
  return (
    <Router>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/signup" component={SignUp} />
      </Switch>
    </Router>
  );
  // <Router>
  //     <Routes>
  //       <Route path="/" element={<Login />}>
  //         <Route index element={<Login />} />
  //         <Route path="login" element={<Login />} />
  //         <Route path="signup" element={<SignUp />} />
  //         {/* <Route path="*" element={<NoPage />} /> */}
  //       </Route>
  //     </Routes>
  //   </Router>
};

export default App;
